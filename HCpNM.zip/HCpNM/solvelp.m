function x = solvelp(alpha, lambda, p)

% Solving the subproblem (11), i.e.,
%    min_{x}  (x-alpha)^2 + lambda*|x|^p

a = (lambda*p*(1-p)/2)^(1/(2-p))+eps;
b = 2*a-2*alpha+lambda*p*a^(p-1);
if b < 0
    x = 2*a;
    for i = 1:10
        f = 2*x-2*alpha+lambda*p*x^(p-1);
        g = 2+lambda*p*(p-1)*x^(p-2);
        x = x-f/g;
    end
    sigma1 = x;
    ob1 = x^2-2*x*alpha+lambda*abs(x)^p;
else
    sigma1 = 1;ob1=inf;
end

a = -a;
b = 2*a-2*alpha+lambda*p*abs(a)^(p-1);
if b > 0
    x = 2*a;
    for i = 1:10
        f = 2*x-2*alpha-lambda*p*abs(x)^(p-1);
        g = 2+lambda*p*(p-1)*abs(x)^(p-2);
        x = x-f/g;
    end
    sigma2 = x;
    ob2 = x^2-2*x*alpha+lambda*abs(x)^p;
else
    sigma2 = 1;ob2=inf;
end
sigma_can = [0,sigma1,sigma2];
[~,idx] = min([0,ob1,ob2]);
x = sigma_can(idx);

end