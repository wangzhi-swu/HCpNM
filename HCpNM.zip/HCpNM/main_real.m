clear;
clc;
addpath(genpath(cd))
 image_list = {'re1.jpg', 're2.jpg', ...
              're3.jpg', 're4.jpg', 're5.jpg', 're6.jpg', 're7.jpg', ...
             're8.jpg','re9.jpg','re10.jpg'};       
file_list = dir('mask');
num_mask = length(file_list) - 2;
mask_list = cell(num_mask, 1);
for i = 1 : num_mask
    mask_list{i} = file_list(i+2).name;
end

image_id = 8;            
mask_id  = 1;            

image_name = image_list{image_id};
img_data = double(imread(image_name))/255;
img_size = size(img_data);
T_flag = 0;%Is transposition,0 isn't transposed.
if img_size(1) < img_size(2)%if m < n, transposition
    img_ori = permute(img_data,[2,1,3]);
    T_flag = 1;
    img_size = [img_size(2),img_size(1),img_size(3)];
else
    img_ori = img_data;
end
sigma_max = svds(img_ori(:,:,1), 1);   
m = img_size(1);
n = img_size(2);

%% block mask
%{
mask = double(imread(mask_list{mask_id}))/255.0;
mask = imresize(mask,img_size(1:2));
omega = zeros(size(mask));
omega_temp = mask(:,:,1);
for channel = 1:3
    omega(:,:,channel) = omega_temp;
end
%}

%% random mask
lost = 0.5;%random mask rate
rnd_idx = randi([0, 100-1], m, n);
old_idx = rnd_idx;
lost = lost * 100;
fprintf('loss: %d%% elements are missing.\n', lost);
rnd_idx = double(old_idx < (100-lost));
omega = rnd_idx; % index matrix of the known elements
omega_temp = omega;
for channel = 1:3
    omega(:,:,channel) = omega_temp;
end

ori=img_ori;

for rgb=1:3
    img_ori(:,:,rgb)=img_ori(:,:,rgb)+0.1 * rand(m,n);
end
figure(1)
subplot(221);
imshow(img_data);
subplot(222);
imshow(img_ori);

omega_img = omega .* img_ori;%input D with loss data
%img_noisy = add_impulse_noise(omega_img, 0.1); % 10%
%omega_img = omega .* img_noisy;


%% parameter(adjust as needed)
max_iter = 100;%iteration times
opt.lambda =3;
tau_s = 0.1 * sigma_max;
opt.tau =400;
opt.taucp=0.9;
mu_max=1;
%% do
best_x=zeros(size(omega_img));
best_psnr=0;
best_p=0;
best_cp=0;
best_snr=0;

for a=0:0.1:1
  for b=0:0.1:1
    opt.p=a;
    opt.pcp=b;
    
    img_new = zeros(size(img_ori)); % the result of completed data
    t_0 = 1;
    X_0 = zeros(img_size);
    A_0 = X_0;
    for channel = 1:3
        opt.omega = omega(:,:,channel);
        opt.D_omega = omega_img(:,:,channel);
        Y_omega = opt.D_omega;
        E_omega = opt.D_omega;
        Z = opt.D_omega;
        W = Y_omega;
        rou = 1.1;
        mv = 0.5;

        for iter = 1:max_iter
            X = opt_X(E_omega,Y_omega,W,Z,mv,opt);
            E_omega = opt_E(X,Y_omega,mv,opt);
            Z = opt_Z(X,W,mv,opt);
            Y_omega = Y_omega + mv*(E_omega - X .* opt.omega + opt.D_omega); 
            W = W + mv*(X - Z);
            mv = rou*mv;
            mv=min(mv,mu_max);
        end
        img_new(:,:,channel) = X;
    end
    img_new=max(img_new,0);
    img_new=min(img_new,1);
    [peaksnr,snr] = psnr(img_new,ori);
   
    fro_norm = norm(img_ori(:) - img_new(:), 2)/norm(img_ori(:), 2);

    if peaksnr>best_psnr
        best_psnr=peaksnr;
        best_x=img_new;
        best_p=opt.p;
        best_cp=opt.pcp;
        best_snr=snr;
    end
  end
end
%% plot
ssimval=ssim(best_x,ori);
fprintf(' the best value of p is: %f, cp is: %f , psnr is: %.2f ,ssim is %.4f \n', best_p,best_cp,best_psnr,ssimval);
subplot(223);
imshow(omega_img);
subplot(224);
imshow(best_x);