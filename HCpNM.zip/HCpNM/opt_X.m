function X = opt_X(E_omega,Y_omega,W,Z,mv,opt)
    D_omega = opt.D_omega;
    omega = opt.omega;
    lambda = opt.lambda;
    omega_ = ones(size(omega)) - omega;
    P_omega = E_omega + D_omega + (1.0/mv)*Y_omega;
    Q = Z - (1.0/mv)*W;
    %N = W - lambda*Z;
    X_omega = (P_omega + Q.*omega)/2.0;
    X_omega_ = Q.*omega_;
    X = X_omega + X_omega_;
end

