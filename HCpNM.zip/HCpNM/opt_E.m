function E_omega = opt_E(X,Y_omega,mv,opt)
    omega = opt.omega;
    D_omega = opt.D_omega;
    p = opt.pcp;
    [m,n] = size(omega);
    E_omega = zeros(size(omega));
    X_omega = X.*omega;
    H_omega = X_omega - D_omega - (1.0/mv)*Y_omega;
    delt=zeros(size(omega));
    tau = opt.taucp;
    lambda=1.0/mv;
    v = (2*lambda*(1-p))^(1.0/(2-p));
    v1 = v + lambda*p*v^(p-1);

    [rows, cols] = find(H_omega); % 获取非零元素的索引
    for k = 1:length(rows)
        i = rows(k);
        j = cols(k);
        s = H_omega(i, j);

        %if s >= v1 
        %    x_ = GST(lambda, p, s);
        %else
        %    x_ = 0;
        %end

        x_=solvelp(s,lambda,p);
        tau_ = ((1.0 / (2 * lambda)) * (x_ - s)^2 + x_^p)^(1.0 / p);
        if tau <= tau_
            delt(i, j) = s;
        else
        delt(i, j) = x_;
        end
    end
    E_omega = delt;  
end

