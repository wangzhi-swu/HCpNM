function img_noisy = add_impulse_noise(img_ori, ratio)
% ratio: 异常比例，比如 0.1 表示10%

[H, W, C] = size(img_ori);
img_noisy = img_ori;

num_pixels = H * W;

% 随机选位置
num_outliers = round(ratio * num_pixels);
idx = randperm(num_pixels, num_outliers);

for c = 1:C
    channel = img_noisy(:,:,c);
    
    % 随机变为0或1
    random_vals = rand(num_outliers,1) > 0.5;
    channel(idx) = random_vals; 
    
    img_noisy(:,:,c) = channel;
end

end